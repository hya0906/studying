21. 09. 03
SEMI_FINAL
최종 취합 및 작동 확인 완료
주석 작성 및 변수이름 선언 다듬을 필요있음.

window 환경변수에 able-store-324904-53433566eb54.json 파일 추가 (tts API용)
linux - vim or vi ~/.bashrc
        export GOOGLE_APPLICATION_CREDENTIALS="/address/able-store-324904-53433566eb54.json" 파일 추가

able-store-324904-53433566eb54.json --> tts API key json파일
abcd-27823-firebase-adminsdk-6hp4e-38c6900af9.json --> firestore key json 파일

b모듈에서 아두이노 환경 값 설정.
record_data 모듈에서 마리아db 환경 값 설정 
c 모듈 작동 시 프로그램 작동 가능.
