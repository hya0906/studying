import numpy as np
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras import regularizers
import matplotlib.pyplot as plt
from keras.optimizers import Adam

def MinMaxScaler(data):
    numerator = data - np.min(data, 0)
    denominator = np.max(data, 0) - np.min(data, 0)
    # noise term prevents the zero division
    return numerator / (denominator + 1e-7)

dataset = np.loadtxt('ThoraricSurgery.csv', delimiter=',')
dataset = MinMaxScaler(dataset)
dataX= dataset[:,:-1]
dataY = dataset[:,[-1]]
X_train,X_test,y_train,y_test = train_test_split(dataX,dataY,test_size=0.148,random_state=9)
X_val,X_train,y_val,y_train = train_test_split(X_train, y_train, test_size=0.75, random_state=123)

def build_model():
    model = Sequential()
    model.add(Dense(17, kernel_regularizer=regularizers.l2(0.001), input_dim=17, activation='sigmoid'))  # 1
    model.add(Dropout(0.2))
    model.add(Dense(34, kernel_regularizer=regularizers.l2(0.001), activation='sigmoid'))  # 2
    model.add(Dropout(0.2))
    model.add(Dense(1, activation='sigmoid'))  # output
    model.compile(loss='binary_crossentropy', optimizer=Adam(lr=0.001), metrics=['accuracy'])
    return model
print(X_train.shape,X_val.shape,X_test.shape)
k = 10
num_val_samples = len(X_train) // k
num_epochs = 20
all_scores = []
for i in range(k):
    print('처리중인 폴드 #', i)
    # 검증 데이터 준비: k번째 분할
    val_data = X_train[i * num_val_samples: (i + 1) * num_val_samples]
    val_targets = y_train[i * num_val_samples: (i + 1) * num_val_samples]

    # 훈련 데이터 준비: 다른 분할 전체
    partial_train_data = np.concatenate(
        [X_train[:i * num_val_samples],
         X_train[(i + 1) * num_val_samples:]],
        axis=0)
    partial_train_targets = np.concatenate(
        [y_train[:i * num_val_samples],
         y_train[(i + 1) * num_val_samples:]],
        axis=0)
    model = build_model()
    train_history = model.fit(partial_train_data, partial_train_targets, epochs=num_epochs, verbose=0, validation_data=(X_val, y_val))
    predict=model.predict(X_test,batch_size=4)

(test_loss, test_acc) = model.evaluate(X_test, y_test, verbose=0)
print('\n테스트 정확도:', test_acc)

epochs = range(1,21)
accuracy = train_history.history['accuracy']
val_accuracy = train_history.history['val_accuracy']
loss = train_history.history['loss']
val_loss = train_history.history['val_loss']

plt.subplot(1,2,1)
plt.plot(epochs, accuracy,'b', label='accuracy')
plt.plot(epochs, val_accuracy,'g', label='val_accuracy')
plt.xlabel('Epochs')
plt.ylabel('accuracy')
plt.legend()

plt.subplot(1,2,2)
plt.plot(epochs, loss, 'r', label='loss')
plt.plot(epochs, val_loss, 'k', label='val_loss')
plt.xlabel('Epochs')
plt.ylabel('loss')
plt.legend()

plt.tight_layout()
plt.show()